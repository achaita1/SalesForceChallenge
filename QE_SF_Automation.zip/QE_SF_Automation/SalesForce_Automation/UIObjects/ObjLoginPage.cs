﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SalesForce_Automation
{
    class ObjLoginPage
    {                       
        public static By userName = By.Id("username");
        public static By passWord = By.Id("password");
        public static By login = By.Id("Login");

    }
}
