﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesForce_Automation.UIObjects
{
    class ObjCases
    {        
        public static By New_bt_Cases_Tab = By.XPath("//div[text()='New']");
        public static By Cases_Tab = By.XPath("//a[@title='Cases']");
        public static By NewCase_tab = By.XPath("(//a[@title='New Case'])[1]");
        public static By Newcase_Title = By.XPath("//h2[text()='New Case']");
        public static By Newcase_Status_dd = By.XPath("//button[@data-value]");
        public static By Newcase_caseOrigin_dd = By.XPath("//span[text()='Case Origin']/../..//a");
        public static By Newcase_caseOrigin_dd_Phone = By.XPath("//a[@title='Phone']");

        public static By Newcase_subject_tb = By.XPath("//span[text()='Subject']/../..//input[@maxlength]");
        
        public static By NewCase_Save_bt = By.XPath("(//span[text()='Save'])[2]");

        public static By CasesDetailsPage_Origin_txt = By.XPath("//span[text()='Case Origin']/../..//lightning-formatted-text");
        public static By CasesDetailsPage_Delete_bt = By.XPath("//button[text()='Delete']");
        
        public static By Delete_popup_bt = By.XPath("//span[text()='Delete']");
        public static By Delete_popup_msg = By.XPath("//*[contains(text(),'Deleted!')]");

    }
}
