﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace SalesForce_Automation
{
    class ObjHomePage
    {
        public static By homeTab = By.XPath(".//a[contains(@title,'Home Tab')]");        
        public static By logOut = By.XPath(".//div[@id='userNavMenu']//a[@title='Logout']");                        
        public static By AppLauncher_icon = By.XPath("//span[text()='App Launcher']/../div");
        public static By AppLauncher_dd = By.XPath("//input[@placeholder='Search apps and items...']");
        public static By Cases_Tab = By.XPath("//a[@title='Cases']");
        public static By NewCase_tab = By.XPath("(//a[@title='New Case'])[1]");
        public static By profile_img = By.XPath("//span[@class='uiImage']");        
        public static By Logout = By.XPath("//div[@id='userNavMenu']//a[@title='Logout']");

    }
}
