﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Reusable_Components;
using NUnit.Framework;
using System.IO;


namespace SalesForce_Automation
{
    [Binding]
    public sealed class Hooks
    {
        private static Logger logger;
        
        
        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            try
            {
                //To log error
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
                String logFile = baseDir + @"Reusable_Components\Report\TestResult\Logs\TestLog.html";
                string path = baseDir + @"Reusable_Components\Report\TestResult\Logs\";


                // Delete previous log details
                System.IO.DirectoryInfo myDirInfo = new DirectoryInfo(path);

                foreach (FileInfo file in myDirInfo.GetFiles())
                {
                    string extn = file.Extension;
                    if (extn.Equals(".html"))
                        file.Delete();
                }

                //Create logfile if not exists
                if (!File.Exists(logFile))
                {
                    File.Create(logFile).Dispose();

                }

                Config.readAppSettings();
                Browser.InvokeDriver(Config.browserType);
                GenericStepDefinitions gs = new GenericStepDefinitions();
                gs.loginToApplication();
                

                logger = new Logger(Browser._driver);

                logger.deleteFilesFromExceptionScreenshot();
                logger.Info("##################### Test Execution Started ######################");
                

            }
            catch(Exception ex)
            {
                logger.Error("Error in 'BeforeTestRun'", ex);               
            }
            
            
        }
        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {            
            try
            {
                string featureName = featureContext.FeatureInfo.Title;
                logger.Info("##################### Feature Execution Started ######################");
                logger.Info("Feature Name: " + "<font color =\"green\"><b>" + featureName + "</b></font>");
                
            }
            catch (Exception ex)
            {
                logger.Info("Error in 'featureIntialize' of report creation", ex);
            }            
        }
                
     

        //TODO: implement logic that has to run before executing each scenario
        [BeforeScenario]
        public static void BeforeScenario(ScenarioContext scenarioContext)
        {
            try
            {             
                string scenarioName = scenarioContext.ScenarioInfo.Title;                
                {
                    GenericStepDefinitions gs = new GenericStepDefinitions();
                    gs.navigateTocasesTab();
                }
            }
            catch(Exception ex)
            {
                logger.Info("Error in 'BeforeScenario'",ex);
            }
           
            try
            {
                string scenarioName = scenarioContext.ScenarioInfo.Title;
                logger.Info("*****Executing scenario**********");
                logger.Info("Scenario Name: " + "<font color =\"blue\"><b>" + scenarioName + "</b></font>");
                
            }
            catch (Exception ex)
            {
                logger.Info("Error in 'scenarioIntialize' of report creation", ex);
            }                                        
        }


        //TODO: implement logic that has to run after executing each scenario

        [AfterScenario]
        public static void AfterScenario(ScenarioContext scenarioContext,FeatureContext featureContext)
        {         
            try
            {
                logger.Info("****** End of Scenario *******");
                
            }
            catch (Exception ex)
            {
                logger.Info("Error in 'scenarioCleanup' of report creation", ex);
            }                       
        }
              

        [AfterFeature]
        public static void AfterFeature()
        {
            

            try
            {
                
                logger.Info("##################### Feature Execution Ends ########################");
                
                
               
                
            }
            catch (Exception ex)
            {
                logger.Info("Error in 'featureCleanup' of report creation", ex);
            }

           

        }
        [AfterTestRun]
        public  static void AfterTestRun()
        {
         
            try
            {
                GenericStepDefinitions gs = new GenericStepDefinitions();                
                Browser.closeDriver();
            }
            catch(Exception ex)
            {
                logger.Info("Error in AfterTestrun", ex);
            }
            
            try
            {
               
                logger.Info("##################### Test Execution Ends ######################");
                
                

            }            
          
            catch (Exception ex)
            {
                logger.Info(ex);

            }

            
        }

        
    }
}
