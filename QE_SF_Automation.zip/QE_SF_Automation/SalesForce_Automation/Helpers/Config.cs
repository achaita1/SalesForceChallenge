﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

namespace SalesForce_Automation
{
    class Config
    {
        public static string username { get; set; }

        public static string password { get; set; }

        public static string sf_Url { get; set;}

        public static string browserType { get; set; }
          
        public static string notificationMailId { get; set; }

        public static void readAppSettings()
        {
            IConfiguration config  = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()) 
        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
        .Build();
            sf_Url = config["SF_URL"];
            username = config["username"];
            password = config["password"];
            browserType = config["browserType"];           
            notificationMailId = config["notificationMailId"];

        }
    }
}
