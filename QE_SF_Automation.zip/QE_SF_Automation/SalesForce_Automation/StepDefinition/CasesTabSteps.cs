﻿using Reusable_Components;
using SalesForce_Automation.PageModules;
using System;
using TechTalk.SpecFlow;

namespace SalesForce_Automation
{
    class CasesTabSteps
    {
        Logger logger = new Logger(Browser._driver);
        
        CasesPage Cp = new CasesPage(Browser._driver);


       


    }
}
