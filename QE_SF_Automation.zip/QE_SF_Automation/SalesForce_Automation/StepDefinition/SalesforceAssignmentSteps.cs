﻿using Reusable_Components;
using SalesForce_Automation.PageModules;
using System;
using TechTalk.SpecFlow;

namespace SalesForce_Automation.StepDefinition
{
    [Binding]
    public class SalesforceAssignmentSteps
    {

        Logger logger = new Logger(Browser._driver);
        
        CasesPage Cp = new CasesPage(Browser._driver);

        [Given(@"a new Case with Origin equal to ""(.*)""")]
        public void GivenANewCaseWithOriginEqualTo(string p0)
        {
            Cp.creatingNewCasewithOriginasPhone(p0);
        }

        [Given(@"Subject equal to ""(.*)""")]
        public void GivenSubjectEqualTo(string p0)
        {
            Cp.enteringCaseSubject(p0);
        }

        [When(@"the Service Agent clicks on Save")]
        public void WhenTheServiceAgentClicksOnSave()
        {
            Cp.ClickingSave();
        }

        [Then(@"the Case Details page should be displayed and Origin should be equal to ""(.*)""")]
        public void ThenTheCaseDetailsPageShouldBeDisplayedAndOriginShouldBeEqualTo(string p0)
        {
            Cp.checkingOrigininCaseDetailsPage(p0);
        }

        [Given(@"without Subject")]
        public void GivenWithoutSubject()
        {
            Cp.enteringCaseSubject();
        }

        [Then(@"the Case Details page should be displayed and Subject should not be blank")]
        public void ThenTheCaseDetailsPageShouldBeDisplayedAndSubjectShouldNotBeBlank()
        {
            Cp.checkingOrigininCaseDetailsPage();
        }

        [Given(@"a Case")]
        public void GivenACase()
        {
            Cp.creatingNewCasewithOriginasPhone("Phone");
            Cp.ClickingSave();

        }

        [When(@"the Service Agent clicks on Delete")]
        public void WhenTheServiceAgentClicksOnDelete()
        {
            Cp.deleteCase();
        }

        [Then(@"an Error Message saying ""(.*)"" should be displayed")]
        public void ThenAnErrorMessageSayingShouldBeDisplayed(string p0)
        {
            Cp.verifyErroMsg(p0);
        }


    }
}
