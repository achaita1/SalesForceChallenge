﻿using System;
using TechTalk.SpecFlow;
using Reusable_Components;

namespace SalesForce_Automation
{
    [Binding]
    public class GenericStepDefinitions
    {
        GeneralModule module = new GeneralModule(Browser._driver);
        LoginPage login = new LoginPage(Browser._driver);
        HomePage home = new HomePage(Browser._driver);
                                 
        public void loginToApplication()
        {
            login.navigateToUrl(Config.sf_Url);
            login.enterUserNameAndPassWord(Config.username, Config.password);
            login.clickloginToApplication();            
        }     
         public void navigateTocasesTab()
        {
            home.goingToCasesTab();
        }
        public void logout()
        {
            home.logout();
        }
    }
}
