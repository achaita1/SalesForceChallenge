﻿using System.Threading;
using System;
using OpenQA.Selenium.Support;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using Reusable_Components;
using log4net;
using SalesForce_Automation;
using SalesForce_Automation.UIObjects;
using OpenQA.Selenium;

namespace SalesForce_Automation.PageModules
{
    class CasesPage
    {
        IWebDriver driver;
        GeneralModule module = new GeneralModule(Browser._driver);
        Logger logger = new Logger(Browser._driver);
       

        public CasesPage(IWebDriver driver)
        {
            this.driver = driver;
        }
       
        public void creatingNewCasewithOriginasPhone(string Phone)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.New_bt_Cases_Tab));
            Thread.Sleep(3000);
            module.WaitForElementToBeVisible(ObjCases.NewCase_tab);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.NewCase_tab));
            module.WaitForElementToBeVisible(ObjCases.Newcase_Title);
            if (!(driver.FindElement(ObjCases.Newcase_Title).Displayed))
                logger.Error("New Case page is not landed");
           
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.Newcase_Title));
            
                 if (!(driver.FindElement(ObjCases.Newcase_Status_dd).GetAttribute("data-value").Contains("New")))
                logger.Error("New Case page is not landed with Status as New.. So failing..");

            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.Newcase_caseOrigin_dd));
            Thread.Sleep(3000);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.Newcase_caseOrigin_dd_Phone));

        }

        public void enteringCaseSubject(string sub)
        {
            driver.FindElement(ObjCases.Newcase_subject_tb).SendKeys(sub);

        }
        public void ClickingSave()
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.NewCase_Save_bt));
        }
        public void checkingOrigininCaseDetailsPage(string phone)
        {            
                  if (!(driver.FindElement(ObjCases.CasesDetailsPage_Origin_txt).Text.Contains(phone)))
                logger.Error("New Case page is created,but Case Origin is NOT Phone...So failing..");
        }
        public void enteringCaseSubject()
        {
            driver.FindElement(ObjCases.Newcase_subject_tb).SendKeys(" ");
        }
        public void checkingOrigininCaseDetailsPage()
        {
            if (!(driver.FindElement(ObjCases.CasesDetailsPage_Origin_txt).Text.Length >= 0 ))
                logger.Error("New Case page is created,but Case Origin is Blank...So failing..");
        }
        public void deleteCase()
        {            
             module.WaitForElementToBeVisible(ObjCases.CasesDetailsPage_Delete_bt);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.CasesDetailsPage_Delete_bt));
            module.WaitForElementToBeVisible(ObjCases.Delete_popup_bt);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjCases.Delete_popup_bt));
        }
        public void verifyErroMsg(string errmsg)
        {
            module.WaitForElementToBeVisible(ObjCases.Delete_popup_msg);
            if (!(driver.FindElement(ObjCases.Delete_popup_msg).Text.Equals(errmsg)))
                logger.Error("Error message is not like expecting.should be.."+errmsg+"So failing..");
        }
    }
}
