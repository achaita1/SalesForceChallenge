﻿using OpenQA.Selenium;
using Reusable_Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace SalesForce_Automation
{
    class HomePage
    {
        IWebDriver driver;
        GeneralModule module = new GeneralModule(Browser._driver);
        LoginPage login = new LoginPage(Browser._driver);
        Logger logger = new Logger(Browser._driver);
        

        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
        }
               
        public void clickingApplauncherandTypeCases()
        {
            try
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjHomePage.AppLauncher_icon));
                Thread.Sleep(3000);
                module.WaitForElementToBeVisible(ObjHomePage.AppLauncher_dd);
                if (!(driver.FindElement(ObjHomePage.AppLauncher_dd).Displayed))
                    logger.Error("App Launcher Dropdown  Not loaded..");
                driver.FindElement(ObjHomePage.AppLauncher_dd).SendKeys("Cases");
                Thread.Sleep(3000);
                module.WaitForElementToBeVisible(ObjHomePage.Cases_Tab);
                if (!(driver.FindElement(ObjHomePage.Cases_Tab).Displayed))
                    logger.Error("Cases SubTab Not loaded...");
            }
            catch (Exception ex)
            {
                logger.Error("Issue in App launcher and entering Cases", ex);
            }

        }
       public void logout()
        {
            driver.FindElement(ObjHomePage.profile_img).Click();
            module.WaitForElementToBeVisible(ObjHomePage.Logout);
            driver.FindElement(ObjHomePage.Logout).Click();
        }

        public void goingToCasesTab()
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", driver.FindElement(ObjHomePage.Cases_Tab));            
        }

       
        
       


    }
}
