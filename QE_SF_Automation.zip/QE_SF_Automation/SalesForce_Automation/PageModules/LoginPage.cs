﻿using OpenQA.Selenium;
using Reusable_Components;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SalesForce_Automation
{
    class LoginPage
    {
        IWebDriver driver;
        GeneralModule module = new GeneralModule(Browser._driver);
        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
        }
        public void navigateToUrl(string url)
        {
            try
            {
                driver.Navigate().GoToUrl(url);

            }
            catch (Exception ex)
            {
                Thread.Sleep(10000);
                module.WaitForElementToBeClickable(ObjLoginPage.userName);
            }
        }
        public void enterUserNameAndPassWord(string username, string password)
        {
            module.WaitForElementToBeClickable(ObjLoginPage.userName);
            driver.FindElement(ObjLoginPage.userName).Clear();
            driver.FindElement(ObjLoginPage.userName).Click();
            Thread.Sleep(2000);
            driver.FindElement(ObjLoginPage.userName).SendKeys(username);
            driver.FindElement(ObjLoginPage.passWord).SendKeys(password);
        }
//Login Function
        public void clickloginToApplication()
        {

            driver.FindElement(ObjLoginPage.login).Click();          
        }
       

    }
}
