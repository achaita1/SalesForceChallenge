﻿using OpenQA.Selenium;
using Reusable_Components;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SalesForce_Automation
{
    class ReportPage
    {
        IWebDriver driver;
        GeneralModule module = new GeneralModule(Browser._driver);
        Logger logger = new Logger(Browser._driver);

        public ReportPage(IWebDriver driver)
        {
            this.driver = driver;
        }
        public void CheckThePageRedirectsToReportWhichContains(string ReportName)
        {
            try
            {
                By xpath = By.XPath("//div[@class='ptBody']//*[contains(text(),'" + ReportName + "')]");
                try
                {
                    module.WaitForElementToBeVisible(xpath);
                    driver.FindElement(xpath);
                }
                catch
                {
                    Thread.Sleep(10000);
                    if (!module.IsElementDisplayed(xpath))
                        logger.Error(ReportName + " is not visible on the current page");
                }
            }
            catch (Exception e)
            {
                logger.Error("Exception occurred in this method CheckThePageRedirectsToReportWhichContains()", e);
            }
        }


    }
}
