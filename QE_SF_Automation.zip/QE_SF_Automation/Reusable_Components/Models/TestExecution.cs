﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Reusable_Components.Models
{
    public partial class TestExecution
    {
        public int Id { get; set; }
        public string Feature { get; set; }
        public string TestCase { get; set; }
        public int PassCount { get; set; }
        public int? FailCount { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public DateTime? LastModifiedDateTime { get; set; }

        public bool IsEnabled { get; set; }
        public bool IsUI { get; set; }
    }
}
