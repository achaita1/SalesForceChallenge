﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Reusable_Components
{
    public class TestScenarioDataDTO
    {
        [JsonProperty("ScenarioName")]
        public string ScenarioName { get; set; }

        [JsonProperty("ScenarioStatus")]
        public string ScenarioStatus { get; set; }

        [JsonProperty("TotalScenarioExecutionTime")]
        public TimeSpan TotalScenarioExecutionTime { get; set; }
    }
}
