﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Reusable_Components
{
    public class TestResultDataDTO
    {
        [JsonProperty("ExecutionDate")]       
        public DateTime ExecutionDate { get; set; }

        [JsonProperty("TotalNumberOfScenarios")]
        public int TotalNumberOfScenarios { get; set; }

        [JsonProperty("PassCount")]
        public int PassCount { get; set; }

        [JsonProperty("FailCount")]
        public int FailCount { get; set; }

        [JsonProperty("PassPercentage")]
        public float PassPercentage { get; set; }


        [JsonProperty("TestScenarioData")]
        public List<TestScenarioDataDTO> TestScenarioDataDTO { get; set; }

        [JsonProperty("FeatureName")]
        public String featureName { get; set; }
    }
}
