﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Text;

namespace Reusable_Components
{
    class MailReporter
    {
        public void sendMail(string notificationMailId)
        {
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "mailo2.uhc.com";
            smtpClient.EnableSsl = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Timeout = 5000;

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
            string htmlFilePath = baseDir + @"Reusable_Components\Report\TestResult\TestExecutionReport.html";


            StreamReader reader = File.OpenText(htmlFilePath);
            MailMessage myMail = new MailMessage();
            myMail.From = new MailAddress(notificationMailId, "Automation User");
            DateTime ExecutionDate = DateTime.Now;
            myMail.Subject = "Automation Result on " + ExecutionDate;
            myMail.IsBodyHtml = true;
            string logFile =  baseDir + @"\Reusable_Components\Report\TestResult\Logs\TestLog.html";
            string logFileDet = baseDir + @"\Reusable_Components\Report\TestResult\Logs\TestLogDet.html";


            File.Copy(logFile, logFileDet);
            System.Net.Mail.Attachment attachment;
            attachment = new System.Net.Mail.Attachment(logFileDet);
            myMail.Attachments.Add(attachment);

            String mailTo = "chaitanya.anna@optum.com";

            String[] mailingList = mailTo.Split(';');
            foreach (String mailID in mailingList)
            {
                myMail.To.Add(new MailAddress(mailID));
            }

            
            myMail.Body = myMail.Body + reader.ReadToEnd();  // Load the content from HTML report file...

            smtpClient.Send(myMail);

        }
    }
}
