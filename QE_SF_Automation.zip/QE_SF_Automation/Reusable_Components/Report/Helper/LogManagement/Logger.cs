﻿using System;
using System.Collections.Generic;
using System.Text;
using log4net;
using log4net.Config;
using System.Diagnostics;

using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using NUnit.Framework;
using OpenQA.Selenium;


namespace Reusable_Components
{
    public class Logger
    {
        private ILog logger;
        private String baseDir = System.AppDomain.CurrentDomain.BaseDirectory;

        Random randomid = new Random();
        IWebDriver driver;


        public Logger(IWebDriver driver)
        {
            this.driver = driver;
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
            string log4netConfig = baseDir + @"Reusable_Components\log4net.config";
            XmlConfigurator.Configure(new System.IO.FileInfo(log4netConfig));

            StackTrace stackTrace = new StackTrace();           // get call stack
            StackFrame[] stackFrames = stackTrace.GetFrames();  // get method calls (frames)

            String className = stackFrames[1].GetMethod().DeclaringType.Name;
            logger = LogManager.GetLogger(className);



        }
        public void Info(Object message)
        {
            logger.Info(message + "<br>");
            Console.WriteLine(message);
        }

        public void Info(Object message, Exception execption)
        {
            logger.Info(message + "<br>", execption);

        }

        public void Error(Object message)
        {
            logger.Error("<font color=\"red\"><b>" + message + "</b></font><br>");
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }

        //Method for error logging for email setup issues
        public void Error(Exception ex)
        {
            logger.Error("<font color=\"red\"><b>" + ex);
        }

        public void Error(Object message, Exception exception)
        {
            logger.Error("<font color=\"red\"><b>" + message + "</b></font><br>", exception);
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }
        public void Error(Object message, string actual, string expected)
        {
            logger.Error("<font color=\"red\"><b>" + message + " Actual Value is: " + actual + " Expected value is: " + expected + "</b></font><br>");
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }

        public void Error(Object message, string actual, string expected, Exception exception)
        {
            logger.Error("<font color=\"red\"><b>" + message + " Actual Value is: " + actual + " Expected value is: " + expected + "</b></font><br>", exception);
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }

        public void Error(Object message, bool actual, bool expected)
        {
            logger.Error("<font color=\"red\"><b>" + message + " Actual Value is: " + actual + " Expected value is: " + expected + "</b></font><br>");
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }

        public void Error(Object message, bool actual, bool expected, Exception exception)
        {
            logger.Error("<font color=\"red\"><b>" + message + " Actual Value is: " + actual + " Expected value is: " + expected + "</b></font><br>", exception);
            int randomNumber = randomid.Next(111111111, 999999999);
            SnapScreenshot("testing" + randomNumber.ToString());
            Assert.Fail(message + "");

        }


        public void Fatal(Object message)
        {
            logger.Fatal("<font color=\"red\"><b>" + message + "</b></font><br>");
            Assert.Fail(message + "");
        }

        public void Fatal(Object message, Exception execption)
        {
            logger.Fatal("<font color=\"red\"><b>" + message + "</b></font><br>", execption);
            Assert.Fail(message + "");

        }
        public void deleteFilesFromExceptionScreenshot()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
            string path = baseDir + @"Reusable_Components\Report\TestResult\ExceptionScreenshot\";


            System.IO.DirectoryInfo myDirInfo = new DirectoryInfo(path);

            foreach (FileInfo file in myDirInfo.GetFiles())
            {
                string extn = file.Extension;
                if (extn.Equals(".Png"))
                    file.Delete();
            }
        }
        public void SnapScreenshot(string scenarioName)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
            //Uncomment below line if running in local 
           string path = baseDir + @"Reusable_Components\Report\TestResult\ExceptionScreenshot\";

            //Below code changes for VM execution and comment out below 2 lines if running through local
            //baseDir = baseDir.Remove(0,10);
            //string path = @"\\wn000022881.ms.ds.uhc.com\" + baseDir + @"\Reusable_Components\Report\TestResult\ExceptionScreenshot\";
           
            String timeStamp = Stopwatch.GetTimestamp().ToString();
            string fileName = scenarioName + "_" + timeStamp;
            string completeFileName = path + fileName + ".Png";

            Screenshot ss = ((ITakesScreenshot)driver)?.GetScreenshot();
            ss?.SaveAsFile(completeFileName, ScreenshotImageFormat.Png);

            Info("Screen Captured and Saved. <a href=" + completeFileName + "><i>Click Here for Screenshot</i></a>");


        }
    }
}
