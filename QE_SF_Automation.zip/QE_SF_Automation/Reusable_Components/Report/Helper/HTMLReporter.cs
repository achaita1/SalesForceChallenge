﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Reusable_Components
{
    public class HtmlReporter
    {
        private static TextWriter reportFile;
        public static int passCount = 0;
        public string testStartTime;
        public string testStopTime;

        
        public void initializeReport()
        {
            
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));
           
            string path = baseDir + @"Reusable_Components\Report\TestResult\TestExecutionReport.html";
            if (!File.Exists(path))
            {
                using (var stream = File.Create(path))
                { }
            }
            reportFile = new StreamWriter(path,false);
            testStartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            reportFile.WriteLine(getHeader());
            reportFile.WriteLine("<img src=\"https://www.optum.com/content/dam/optum/Skin/Logos/optum_2x.png\" width=\"90\" height=\"30\"></img>");
            reportFile.WriteLine("<hr>");
           

        }

        public void initializeFeatureData(TestResultDataDTO testResultDataDTO)
        {
            reportFile.WriteLine("<h2 align=\"left\">" + testResultDataDTO.featureName + " - Automation Report" + "</h2>");
            reportFile.WriteLine("<table id=\"t01\">");
            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<th style=\"width:25%\"><b>Scenario Name<b></th>");
            reportFile.WriteLine("<th style=\"width:10%\"><b>Execution Time<b></th>");
            reportFile.WriteLine("<th style=\"width:5%\"><b>Status<b></th>");
            reportFile.WriteLine("</tr>");
        }
        public void concludeFeatureData(TestResultDataDTO testResultDataDTO)
        {



            /* Adding the feature name on the screen*/

            
            string bgColor=null;
            for (int i = 0; i < testResultDataDTO.TotalNumberOfScenarios; i++)
            {
                if (testResultDataDTO.TestScenarioDataDTO[i].ScenarioStatus.Equals("Pass"))
                {
                    bgColor = "bgcolor = \"lightgreen\"";
                    passCount = passCount + 1;
                }
                else
                {
                    bgColor = "bgcolor = \"red\"";
                }
                
                reportFile.WriteLine("<tr>");
                reportFile.WriteLine("<td>" + testResultDataDTO.TestScenarioDataDTO[i].ScenarioName + "</td>");
                reportFile.WriteLine("<td>" + testResultDataDTO.TestScenarioDataDTO[i].TotalScenarioExecutionTime + "</td>");
                reportFile.WriteLine("<td " + bgColor + ">" + testResultDataDTO.TestScenarioDataDTO[i].ScenarioStatus + "</a></td>");
                reportFile.WriteLine("</tr>");
                
            }
            reportFile.WriteLine("</table>");



        }

        public void concludeReport(TestResultDataDTO testResultDataDTO)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            baseDir = Path.GetFullPath(Path.Combine(baseDir, @"../../../../"));

            testStopTime = DateTime.Now.ToString("yyyy -MM-dd HH:mm:ss");
            testResultDataDTO.PassPercentage = (testResultDataDTO.PassCount / (float)testResultDataDTO.TotalNumberOfScenarios) * 100;
           
            reportFile.WriteLine("<br>");
            reportFile.WriteLine("<br>");
            reportFile.WriteLine("<table style=\"width:30%\">");

            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>Total Execution Time</td>");
            reportFile.WriteLine("<td><i>" + (Convert.ToDateTime(testStopTime) - Convert.ToDateTime(testStartTime)) + "</i></td>");
            reportFile.WriteLine("</tr>");

            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>Total Number of Test Cases</td>");
            reportFile.WriteLine("<td>" + testResultDataDTO.TotalNumberOfScenarios + "</td>");
            reportFile.WriteLine("</tr>");
            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>Pass Count</td>");
            reportFile.WriteLine("<td>" + testResultDataDTO.PassCount + "</td>");
            reportFile.WriteLine("</tr>");
            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>Fail Count</td>");
            reportFile.WriteLine("<td>" + (testResultDataDTO.TotalNumberOfScenarios - testResultDataDTO.PassCount) + "</td>");
            reportFile.WriteLine("</tr>");
            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>ExecutionDate</td>");
            reportFile.WriteLine("<td>" + testResultDataDTO.ExecutionDate + "</td>");
            reportFile.WriteLine("</tr>");
            reportFile.WriteLine("<tr>");
            reportFile.WriteLine("<td>Pass Percentage</td>");
            reportFile.WriteLine("<td>" + testResultDataDTO.PassPercentage + "</td>");
            reportFile.WriteLine("</tr>");

                

            reportFile.WriteLine("</table>");
            reportFile.WriteLine("</body>");
            reportFile.WriteLine("<br>");
            reportFile.WriteLine("</html>");
            reportFile.Close();
        }

        private string getHeader()
        {
            string header = "<!DOCTYPE html>" +
"<html>" +
"<head>" +
"<style>" +
"table {" +
    "width:80%;" +
"}" +
"table, th, td {" +
    "border: 1px solid black;" +
    "border-collapse: collapse;" +
"}" +
"td {" +
    "padding: 5px;" +
    "text-align: left;" +
"}" +
"th {" +
    "padding: 5px;" +
    "text-align: center;" +
"}" +
"table#t01 tr:nth-child(even) {" +
    "background-color: #BDBDBD;" +
"}" +
"table#t01 tr:nth-child(odd) {" +
   "background-color:#fff;" +
"}" +
"table#t01 th	{" +
    "background-color: #bac4cf;" +
    "color: black;" +
"}" +
".topright {" +
    "position: absolute;" +
    "font-size: 18px;" +
    "top: 8px;" +
    "right: 16px;" +
"}" +
"</style>" +
"</head>" +
"<body>";

            return header;
        }
    }
}
