﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Drawing.Imaging;
using System.Threading;

namespace Reusable_Components
{
    public class GeneralModule
    {
        IWebDriver driver;
       
        public GeneralModule(IWebDriver driver)
        {
            this.driver = driver;
        }

      

        //Method to set Value in edit Field
        public void setValue(GeneralModule.editField editField, string obj, string value)
      
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            switch (editField)
            {
                case editField.id:
                    js.ExecuteScript("document.getElementById( '" + obj + "').setAttribute('value', '" + value + "')");
                    break;
                case editField.name:
                    break;
            }

        }


        public void OnChangeEventExecution(IWebElement element)
        {
            IJavaScriptExecutor jsExecutor = (IJavaScriptExecutor)driver;
            jsExecutor.ExecuteScript("$(arguments[0]).change();", element);
        }

        //Enum for Attributes of Edit Fields
        public enum editField
        {
            id,
            name            
        }

        //Method to Wait for input element To be Visible
        public void WaitForElementToBeVisible(By selector, int timeoutSec = 50)
        {
            
                WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
                 wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(selector));
            
           
            
        }

        public void WaitForElementToBeClickable(By selector, int timeoutSec = 100)
        {
            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(selector));
        }

        public void WaitForElementToBePresent(IWebDriver _driver, By selector, int timeoutSec = 100)
        {
            
            WebDriverWait wait = new WebDriverWait(_driver, new TimeSpan(0, 0, timeoutSec));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(selector));



        }

        public Boolean IsElementDisplayed(By Xpath)
        {
            try
            {
                if (driver.FindElement(Xpath).Displayed)
                    return true;
                else if (!driver.FindElement(Xpath).Displayed)
                    return false;
            }
            catch (Exception e)
            {
                return false;
            }
            return false;
        }

    }
}
