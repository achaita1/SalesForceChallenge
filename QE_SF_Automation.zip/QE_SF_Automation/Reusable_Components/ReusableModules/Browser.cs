﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Edge;

namespace Reusable_Components
{
    public class Browser
    {
        public static IWebDriver _driver;
      
        
        //Method to invoke driver depending upon input Browser Type
        public static void InvokeDriver(string input)
        {
            string browserType = input.Trim();
            if (browserType.Equals("InternetExplorer"))
            {
               
                CloseProcess("iexplore");
                var options = new InternetExplorerOptions();
                options.EnsureCleanSession = true;

                options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                options.IgnoreZoomLevel = true;
                options.EnableNativeEvents = false;
                
                string basedir = System.AppDomain.CurrentDomain.BaseDirectory;
                basedir = Path.GetFullPath(Path.Combine(basedir, @"../../../.."));
                _driver = new InternetExplorerDriver(basedir + "\\Reusable_Components\\BrowserDrivers\\IEDriver", options);
                _driver.Manage().Window.Maximize();
            }
            else if (browserType.Equals("Chrome"))
            {

               // CloseProcess("chrome");
                var chromeOptions = new ChromeOptions();
                chromeOptions.AddArguments("disable-infobars");
                chromeOptions.AddArguments("start-maximized");
                chromeOptions.AddArguments("--disable-extensions");
                chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                chromeOptions.AddUserProfilePreference("intl.accept_languages", "en");
                chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
                string basedir = System.AppDomain.CurrentDomain.BaseDirectory;
                basedir = Path.GetFullPath(Path.Combine(basedir, @"../../../.."));
                _driver = new ChromeDriver(basedir + "\\Reusable_Components\\BrowserDrivers\\ChromeDriver", chromeOptions);
            }
         

        }

        //Method to Close all running instances of input process
        public static  void CloseProcess(string processName)
        {
            
            Process[] AllProcesses = Process.GetProcesses();
            foreach (var process in AllProcesses)
            {
                if (process.MainWindowTitle != "")
                {
                    string procName = process.ProcessName.ToLower();
                    if (procName == processName)
                        process.Kill();
                }
                
            }
        
        
        }

        public static void DeleteCookies()
        {
            Logger logger = new Logger(_driver);
            if (_driver == null) return;
            _driver.Manage().Cookies.DeleteAllCookies();
            logger.Info("Deleting Cookies Started");

            if (_driver.GetType() == typeof(OpenQA.Selenium.IE.InternetExplorerDriver))
            {              

                ProcessStartInfo psInfo = new ProcessStartInfo();
                logger.Info("Deleting Cookies In Progress");
                psInfo.FileName = Path.Combine(Environment.SystemDirectory, "RunDll32.exe");
                psInfo.Arguments = "InetCpl.cpl,ClearMyTracksByProcess 2";
                psInfo.CreateNoWindow = true;
                psInfo.UseShellExecute = false;
                psInfo.RedirectStandardError = true;
                psInfo.RedirectStandardOutput = true;
                Process p = new Process { StartInfo = psInfo };
                p.Start();
                p.WaitForExit(10000);
            }
            logger.Info("Deleting Cookies Completed");
        }
        //Method to Quit Driver
        public static void closeDriver()
        {
            _driver.Close();
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
